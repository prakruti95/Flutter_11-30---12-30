<?php

  include('connection.php');


    //this is our upload folder
    $upload_path = 'product_images/';

    //creating the upload url
    $upload_url = 'https://'.$_SERVER['SERVER_NAME'] . "/MiniProject/" . $upload_path;


    $product_id= $_POST['product_id'];
    $product_name= $_POST['product_name'];
    $product_price= $_POST['product_price'];
    $final_discounted_price= $_POST['final_discounted_price'];
    $features= $_POST['features'];
    $ratings= $_POST['ratings'];
    $quantity= $_POST['quantity'];


    //getting user photo information
    $fileinfo1 = pathinfo($_FILES["product_image"]["name"]);

    //getting user photo extension
    $extension1 = $fileinfo1["extension"];

    //random name for user photo
    $random1 = 'user_' . rand(1000,9999);

    //user photo url
    $product_photo_url = $upload_url . $random1 . '.' . $extension1;

    //user photo path
    $product_photo_path = $upload_path . $random1 . '.' . $extension1;


    //saving product
    move_uploaded_file(
        $_FILES["product_image"]["tmp_name"],
        $product_photo_path 
    );




    if($product_name== "" && $product_price== "" && $final_discounted_price== "" && $features== "" && $ratings== "" && $quantity== "" && $product_id == "")
    {
        echo '0';
    }
    else 
    {
        $sql = "update mini_products set 
        product_name= '$product_name',
        product_price= '$product_price',
        final_discounted_price= '$final_discounted_price',
        ratings= '$ratings',
        features= '$features',
        quantity= '$quantity',
        product_image= '$product_image'
        where product_id  = '$product_id'";


        mysqli_query($con, $sql);
        //echo '1';   
    }
        

?>